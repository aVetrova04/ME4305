"""Outer line loop: sensor position -> requested left/right wheel speeds."""

from array import array
from time import ticks_us, ticks_diff
from line_config import LINE_LOG_SAMPLES, LINE_PERIOD_MS, MAX_WHEEL_RAD_S


class LineData:
    """Shared requests and fixed-size log; TaskUser never touches the ADC."""

    def __init__(self):
        self.start_request = False
        self.stop_request = False
        self.capture_request = False
        self.running = False
        self.ready = False
        self.failed = False
        self.error = ""
        self.base_speed = 2.0
        self.line_kp = 0.05  # (rad/s) per mm; tune with Romi on the paper.
        self.inner_kp = 0.0
        self.count = 0
        self.time_us = array('L', (0 for _ in range(LINE_LOG_SAMPLES)))
        self.centroid_mm = array('f', (0 for _ in range(LINE_LOG_SAMPLES)))
        self.total_weight = array('f', (0 for _ in range(LINE_LOG_SAMPLES)))
        self.left_rad_s = array('f', (0 for _ in range(LINE_LOG_SAMPLES)))
        self.right_rad_s = array('f', (0 for _ in range(LINE_LOG_SAMPLES)))


class TaskLine:
    S_IDLE = 0
    S_FOLLOW = 1

    def __init__(self, sensor, left_data, right_data, line_data):
        self.sensor = sensor
        self.left = left_data
        self.right = right_data
        self.data = line_data
        self.state = self.S_IDLE
        self.capture_start_us = 0

    def stop(self, error=""):
        # Motor tasks own their drivers and act on these flags next dispatch.
        self.left.follow_stop = True
        self.right.follow_stop = True
        self.data.running = False
        self.data.start_request = False
        self.data.stop_request = False
        self.data.capture_request = False
        self.data.ready = False
        self.data.failed = bool(error)
        self.data.error = error
        self.capture_start_us = 0
        self.state = self.S_IDLE

    def taskline_gen_fcn(self):
        while True:
            if self.state == self.S_IDLE:
                if self.data.start_request:
                    self.data.start_request = False
                    if self.sensor.positions_mm is None or self.sensor.black is None:
                        self.stop("Check sensor orientation and calibration")
                    elif self.left.busy or self.right.busy or self.left.ready or \
                            self.right.ready or self.left.following or self.right.following:
                        self.stop("Wait for both wheel tasks to stop")
                    elif not 0 < self.data.base_speed <= MAX_WHEEL_RAD_S or \
                            self.data.inner_kp <= 0 or self.data.line_kp < 0:
                        self.stop("Check base speed and controller gains")
                    else:
                        self.data.failed = False
                        self.data.error = ""
                        self.data.ready = False
                        self.capture_start_us = 0
                        self.data.running = True
                        self.left.follow_kp = self.data.inner_kp
                        self.right.follow_kp = self.data.inner_kp
                        self.left.follow_setpoint = self.data.base_speed
                        self.right.follow_setpoint = self.data.base_speed
                        self.left.follow_stop = False
                        self.right.follow_stop = False
                        self.left.follow_request = True
                        self.right.follow_request = True
                        self.state = self.S_FOLLOW

            elif self.state == self.S_FOLLOW:
                if self.data.stop_request:
                    self.stop()
                elif self.left.failed or self.right.failed:
                    self.stop("A wheel controller failed")
                elif not self.left.following or not self.right.following:
                    # Motor tasks may not have run yet on the first dispatch.
                    if not self.left.follow_request and not self.right.follow_request:
                        self.stop("Wheel controller stopped unexpectedly")
                else:
                    try:
                        centroid = self.sensor.centroid()
                        if centroid is None:
                            self.stop("Line not detected; both motors stopped")
                        else:
                            correction = self.data.line_kp * centroid
                            left = self.data.base_speed - correction
                            right = self.data.base_speed + correction
                            left = max(0.0, min(MAX_WHEEL_RAD_S, left))
                            right = max(0.0, min(MAX_WHEEL_RAD_S, right))
                            self.left.follow_setpoint = left
                            self.right.follow_setpoint = right

                            if self.data.capture_request:
                                self.data.capture_request = False
                                self.data.ready = False
                                self.data.count = 0
                                self.capture_start_us = ticks_us()

                            if not self.data.ready and self.capture_start_us:
                                i = self.data.count
                                self.data.time_us[i] = ticks_diff(
                                    ticks_us(), self.capture_start_us)
                                self.data.centroid_mm[i] = centroid
                                self.data.total_weight[i] = self.sensor.total_weight
                                self.data.left_rad_s[i] = left
                                self.data.right_rad_s[i] = right
                                self.data.count += 1
                                if self.data.count == LINE_LOG_SAMPLES:
                                    self.data.ready = True
                                    self.capture_start_us = 0
                    except Exception as error:
                        self.stop("Sensor/control error: {}".format(error))

            yield self.state
