from pyb import Pin, Timer, USB_VCP

from MotorDriver import MotorDriver
from EncoderDriver import EncoderDriver
from ClosedLoop import ClosedLoop
from taskmotor import MotorData, TaskMotor
from taskuser import TaskUser
from LineSensor import LineSensor
from line_calibration import calibrate, load
from line_config import (SENSOR_PINS, SENSOR_1_ON_LEFT,
                         ADC_READS_PER_CHANNEL, MIN_CALIBRATION_SPAN,
                         CALIBRATION_FILE, CALIBRATE_ON_BOOT,
                         LINE_PERIOD_MS, UI_PERIOD_MS, MOTOR_PERIOD_MS)
from taskline import LineData, TaskLine
import cotask


# measure the battery under load; this is not an ADC battery monitor.
BATTERY_V = 7


class SystemData:
    def __init__(self):
        self.exit_requested = False


def main():
    if BATTERY_V is None or not 3 <= BATTERY_V <= 12:
        raise ValueError("Set BATTERY_V in main.py to the measured battery voltage")

    pwm_tim = Timer(2, freq=20_000)
    left_motor = MotorDriver(Pin.cpu.A0, Pin.cpu.A6, Pin.cpu.C6,
                             pwm_tim, 1)
    right_motor = MotorDriver(Pin.cpu.A1, Pin.cpu.A7, Pin.cpu.C5,
                              pwm_tim, 2)

    left_enc = EncoderDriver(1, Pin.cpu.A8, Pin.cpu.A9)
    right_enc = EncoderDriver(3, Pin.cpu.B4, Pin.cpu.B5)
    left_data = MotorData()
    right_data = MotorData()
    line_data = LineData()
    system = SystemData()

    left_task = TaskMotor(left_motor, left_enc, left_data,
                          ClosedLoop(), BATTERY_V)
    right_task = TaskMotor(right_motor, right_enc, right_data,
                           ClosedLoop(), BATTERY_V)
    vcp = USB_VCP()

    try:
        sensor = LineSensor(SENSOR_PINS, SENSOR_1_ON_LEFT,
                            ADC_READS_PER_CHANNEL, MIN_CALIBRATION_SPAN)
        if CALIBRATE_ON_BOOT:
            calibrate(sensor, vcp, CALIBRATION_FILE)
        else:
            try:
                load(sensor, CALIBRATION_FILE)
            except (OSError, KeyError, TypeError, ValueError) as error:
                print("Line calibration unavailable:", error)
                print("Wheel tests still work. Set CALIBRATE_ON_BOOT in line_config.py.")

        if SENSOR_1_ON_LEFT is None:
            print("Check sensor physical order and set SENSOR_1_ON_LEFT before following.")
        if len(SENSOR_PINS) != 13:
            print("Sensor prototype has {} channels; lab specifies 13.".format(
                len(SENSOR_PINS)))

        line_task = TaskLine(sensor, left_data, right_data, line_data)
        user_task = TaskUser(vcp, left_data, right_data, line_data, system)

        cotask.task_list.append(cotask.Task(
            left_task.taskmotor_gen_fcn(), name="Left_Motor",
            priority=2, period=MOTOR_PERIOD_MS, profile=True))
        cotask.task_list.append(cotask.Task(
            right_task.taskmotor_gen_fcn(), name="Right_Motor",
            priority=2, period=MOTOR_PERIOD_MS, profile=True))
        cotask.task_list.append(cotask.Task(
            line_task.taskline_gen_fcn(), name="Line",
            priority=2, period=LINE_PERIOD_MS, profile=True))
        cotask.task_list.append(cotask.Task(
            user_task.taskuser_gen_fcn(), name="User",
            priority=1, period=UI_PERIOD_MS, profile=True))

        while not system.exit_requested:
            cotask.task_list.pri_sched()
    except KeyboardInterrupt:
        pass
    finally:
        line_data.stop_request = True
        left_task.stop()
        right_task.stop()


if __name__ == "__main__":
    main()
