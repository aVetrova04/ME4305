"""Standalone line sensor display for the Romi USB serial port.

Run from the MicroPython REPL after stopping main.py with Ctrl-C.
Starts with the proposed QTR channels 3..10; no motor or scheduler runs.
"""

from pyb import ADC, Pin, USB_VCP, delay


# After moving sensor-side leads, map printed QTR outputs 3..10 in order
# onto the eight MCU pins already shown in NUCLEO PIN LAYOUT-3.pdf.
# The original W1/Y2/... harness labels still name the MCU leads, not the
# new printed QTR output numbers. Confirm each one before calibration.
SENSOR_MAP = (
    (3, "C0"),   # original W1 MCU lead: CN8 pin 38
    (4, "C1"),   # original Y2 MCU lead: CN8 pin 36
    (5, "C2"),   # original W3 MCU lead: CN7 pin 35
    (6, "C3"),   # original Y4 MCU lead: CN7 pin 37
    (7, "A4"),   # original W5 MCU lead: CN8 pin 32
    (8, "C4"),   # original Y6 MCU lead: CN10 pin 34
    (9, "B0"),   # original W7 MCU lead: CN8 pin 34
    (10, "B1"),  # original Y8 MCU lead: CN10 pin 24
)


# Current Lab 0x05 motor and encoder pins from main.py. Update if they move.
OTHER_PINS = ("A0", "A1", "A6", "A7", "C6", "C5",
              "A8", "A9", "B4", "B5")


def make_frame(readings, sensor_map, full_scale=4095, width=32):
    lines = ["Romi line sensor ADC (q to quit)",
             "Sensor  MCU pin  Raw ADC  Bar"]

    for (sensor_number, pin_name), value in zip(sensor_map, readings):
        clipped = min(full_scale, max(0, value))
        size = int(width * clipped / full_scale)
        lines.append("{:>6}  {:>7}  {:>7}  |{}{}|".format(
            sensor_number, pin_name, value,
            "#" * size, " " * (width - size)))

    frame = "\x1b[H"
    for row in lines:
        frame += "\x1b[2K" + row + "\r\n"
    return frame


def make_adcs(sensor_map):
    if not 1 <= len(sensor_map) <= 13:
        raise ValueError("List between one and thirteen connected sensors")

    numbers = []
    pins = []
    adcs = []
    for number, pin_name in sensor_map:
        if not isinstance(number, int) or not 1 <= number <= 13:
            raise ValueError("Set each physical sensor number from 1 to 13")
        if not isinstance(pin_name, str) or not pin_name:
            raise ValueError("Set each MCU pin name, for example 'C0'")
        if number in numbers or pin_name in pins:
            raise ValueError("A sensor number or MCU pin is listed twice")
        if pin_name in OTHER_PINS:
            raise ValueError("{} is already used by the Lab 0x05 motors/encoders".format(pin_name))

        numbers.append(number)
        pins.append(pin_name)
        try:
            adcs.append(ADC(getattr(Pin.cpu, pin_name)))
        except (AttributeError, ValueError) as error:
            raise ValueError("Check pin {}: {}".format(pin_name, error))

    return adcs


def plot_adc(adcs, sensor_map, refresh_ms=100):
    vcp = USB_VCP()
    vcp.write(b"\x1b[2J\x1b[H")

    try:
        while True:
            if vcp.any():
                command = vcp.read()
                if command and (b"q" in command or b"Q" in command):
                    break

            # One ADC conversion per connected sensor on each screen update.
            readings = [adc.read() for adc in adcs]
            vcp.write(make_frame(readings, sensor_map).encode())
            delay(refresh_ms)
    except KeyboardInterrupt:
        pass
    finally:
        vcp.write(b"\r\nSensor display stopped.\r\n")


def main():
    adcs = make_adcs(SENSOR_MAP)
    plot_adc(adcs, SENSOR_MAP)


if __name__ == "__main__":
    main()
