"""Lab 0x06 pin map and settings. Check these against the actual Romi wiring."""

from pyb import Pin


# Sensor-side rewiring plan: keep these eight MCU leads from the drawing,
# but connect them in order to QTR outputs 3 through 10. Verify each QTR
# number on the board before running; these are NOT the old W1/Y2 numbers.
# The 13-channel bar is centered on printed output 7.
SENSOR_PINS = (
    (3, Pin.cpu.C0),   # original W1 MCU lead, CN8 pin 38
    (4, Pin.cpu.C1),   # original Y2 MCU lead, CN8 pin 36
    (5, Pin.cpu.C2),   # original W3 MCU lead, CN7 pin 35
    (6, Pin.cpu.C3),   # original Y4 MCU lead, CN7 pin 37
    (7, Pin.cpu.A4),   # original W5 MCU lead, CN8 pin 32
    (8, Pin.cpu.C4),   # original Y6 MCU lead, CN10 pin 34
    (9, Pin.cpu.B0),   # original W7 MCU lead, CN8 pin 34
    (10, Pin.cpu.B1),  # original Y8 MCU lead, CN10 pin 24
)

# Set True if lower printed numbers (for example 3) are on Romi's LEFT;
# False if lower printed numbers are on its RIGHT. Channel 1 need not be wired.
# Leave None until the stationary bar test establishes the physical direction.
SENSOR_1_ON_LEFT = None

# Lab handout asks for 13 sensor channels and a 14th ADC reserved for battery.
# Eight channels here are a wiring prototype, not evidence of 13-channel work.
ADC_READS_PER_CHANNEL = 4
MIN_CALIBRATION_SPAN = 30  # ADC counts; verify against measured contrast.
CALIBRATE_ON_BOOT = False  # Turn on with PuTTY open; turn off after saving JSON.
CALIBRATION_FILE = "line_calibration.json"

MOTOR_PERIOD_MS = 10
LINE_PERIOD_MS = 20
UI_PERIOD_MS = 20
LINE_LOG_SAMPLES = 400  # A finite 8 s capture; following continues afterward.
MAX_WHEEL_RAD_S = 10.0  # Lower this if loaded-wheel testing finds a lower limit.
