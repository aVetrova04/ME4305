class MultiChar:
    """Read one signed decimal number from the VCP without blocking."""

    def __init__(self, vcp):
        self.vcp = vcp
        self.value = 0.0
        self.reset()

    def reset(self):
        self.chars = []
        self.done = False
        self.changed = False
        self.exit_requested = False
        self.stop_requested = False

    def update(self):
        if self.done:
            return True
        if not self.vcp.any():
            return False

        raw = self.vcp.read(1)
        if not raw:
            return False
        char = raw.decode()

        if char in ("e", "E"):
            self.done = True
            self.exit_requested = True
        elif char in ("s", "S"):
            self.done = True
            self.stop_requested = True
        elif char in "0123456789" or (char == "-" and not self.chars) or \
                (char == "." and "." not in self.chars):
            if len(self.chars) < 20:
                self.chars.append(char)
                self.vcp.write(char.encode())
        elif char in ("\x08", "\x7f"):
            if self.chars:
                self.chars.pop()
                self.vcp.write(b"\b \b")
        elif char in ("\r", "\n"):
            self.vcp.write(b"\r\n")
            try:
                number = float("".join(self.chars))
                if number != number or abs(number) == float("inf"):
                    raise ValueError
            except ValueError:
                self.vcp.write(b"Invalid value\r\n")
            else:
                self.value = number
                self.changed = True
                self.vcp.write(("Value set to {}\r\n".format(number)).encode())
            self.done = True

        return self.done

    def get_value(self):
        return self.value

    def was_changed(self):
        return self.changed
