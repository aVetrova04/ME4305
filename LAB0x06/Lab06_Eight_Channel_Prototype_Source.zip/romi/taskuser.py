from MultiChar import MultiChar
from line_config import (ADC_READS_PER_CHANNEL, LINE_LOG_SAMPLES,
                         LINE_PERIOD_MS, MAX_WHEEL_RAD_S, SENSOR_PINS,
                         SENSOR_1_ON_LEFT)


class TaskUser:
    """Read the USB menu and print one response row per dispatch."""

    S_WAIT = 0
    S_VEL = 1
    S_GAIN = 2
    S_KP = 3
    S_WAIT_RESULT = 4
    S_PRINT = 5
    S_EXIT = 6
    S_BASE = 7
    S_STEER = 8
    S_LINE_WAIT = 9
    S_LINE_PRINT = 10

    def __init__(self, vcp, left_data, right_data, line_data, system):
        self.vcp = vcp
        self.left_data = left_data
        self.right_data = right_data
        self.line_data = line_data
        self.system = system
        self.input = MultiChar(vcp)
        self.state = self.S_WAIT
        self.active = None
        self.name = ""
        self.setpoint = 0.0
        self.kp = 0.0
        self.header = []
        self.header_index = 0
        self.row_index = 0
        self.base_speed = 2.0
        self.line_kp = 0.05
        self.waiting_for_line_start = False

    def write_line(self, text):
        self.vcp.write((text + "\r\n").encode())

    def menu(self):
        self.write_line("h help | v wheel test speed | k then p wheel gain | l/r wheel test")
        self.write_line("b base speed | g line gain | f follow | c capture | s stop | e exit")
        self.write_line("Enter a single-character command:")

    def exit_program(self):
        self.line_data.stop_request = True
        self.left_data.stop_request = True
        self.right_data.stop_request = True
        if self.active is not None:
            self.write_line("# {} MOTOR TEST ABORTED".format(self.name))
        self.write_line("Exit requested.")
        self.system.exit_requested = True
        self.state = self.S_EXIT

    def stop_during_test(self):
        if self.vcp.any():
            char = self.vcp.read(1)
            if char in (b"e", b"E"):
                self.exit_program()
                return True
            if char in (b"s", b"S"):
                self.active.stop_request = True
                self.write_line("# {} MOTOR TEST ABORTED".format(self.name))
                self.active = None
                self.state = self.S_WAIT
                self.menu()
                return True
        return False

    def stop_line(self):
        self.line_data.start_request = False
        self.line_data.stop_request = self.line_data.running
        self.waiting_for_line_start = False
        self.write_line("Line following stop requested.")
        self.state = self.S_WAIT
        self.menu()

    def start_line(self):
        if self.line_data.running or self.line_data.start_request:
            self.write_line("Line following is already running")
            return
        if self.line_data.ready or self.left_data.following or \
                self.right_data.following or self.left_data.busy or self.right_data.busy or \
                self.left_data.ready or self.right_data.ready:
            self.write_line("Wait for the motor test/output to finish")
            return
        if self.kp <= 0:
            self.write_line("Set a positive loaded-wheel Kp with k then p")
            return
        self.line_data.inner_kp = self.kp
        self.line_data.base_speed = self.base_speed
        self.line_data.line_kp = self.line_kp
        self.line_data.stop_request = False
        self.line_data.start_request = True
        self.waiting_for_line_start = True
        self.write_line("Starting line following.")

    def capture_line(self):
        if not self.line_data.running or self.line_data.capture_request or \
                self.line_data.ready:
            self.write_line("Capture unavailable: start following or finish output")
            return
        self.line_data.capture_request = True
        self.write_line("Line data capture started.")
        self.state = self.S_LINE_WAIT

    def make_line_header(self):
        self.header = [
            "# LINE FOLLOWING DATA",
            "# sensor_channels={}".format("|".join(str(n) for n, pin in SENSOR_PINS)),
            "# sensor_count={}".format(len(SENSOR_PINS)),
            "# channel_1_side={}".format("left" if SENSOR_1_ON_LEFT else "right"),
            "# adc_method=ADC.read",
            "# adc_reads_per_channel={}".format(ADC_READS_PER_CHANNEL),
            "# base_rad_s={}".format(self.line_data.base_speed),
            "# outer_kp_rad_s_per_mm={}".format(self.line_data.line_kp),
            "# inner_kp_v_per_rad_s={}".format(self.line_data.inner_kp),
            "# motor_period_ms={}".format(self.left_data.motor_period_ms),
            "# line_period_ms={}".format(LINE_PERIOD_MS),
            "# ui_period_ms={}".format(self.left_data.ui_period_ms),
            "# max_wheel_rad_s={}".format(MAX_WHEEL_RAD_S),
            "# battery_voltage_v={}".format(self.left_data.battery_v),
            "# samples={}".format(LINE_LOG_SAMPLES),
            "# units=us,mm,unitless,rad/s,rad/s",
            "time_us,centroid_mm,total_weight,left_setpoint_rad_s,right_setpoint_rad_s"
        ]
        self.header_index = 0
        self.row_index = 0

    def start_test(self, side):
        if (self.line_data.running or self.line_data.start_request or
                self.left_data.following or self.right_data.following or
                self.left_data.busy or self.left_data.ready or
                self.right_data.busy or self.right_data.ready):
            self.write_line("Test unavailable: wait for current test/output to finish.")
            return
        self.active = self.left_data if side == "LEFT" else self.right_data
        self.name = side
        self.active.setpoint = self.setpoint
        self.active.kp = self.kp
        self.active.request = True
        self.write_line("Starting {} motor step-response.".format(side))
        self.state = self.S_WAIT_RESULT

    def make_header(self):
        data = self.active
        self.header = [
            "# {} MOTOR CLOSED-LOOP STEP RESPONSE".format(self.name),
            "# motor={}".format(self.name),
            "# control=P",
            "# setpoint_rad_s={}".format(data.setpoint),
            "# kp_v_per_rad_s={}".format(data.kp),
            "# motor_period_ms={}".format(data.motor_period_ms),
            "# ui_period_ms={}".format(data.ui_period_ms),
            "# duration_ms={}".format(data.count * data.motor_period_ms),
            "# battery_voltage_v={}".format(data.battery_v),
            "# voltage_min_v={}".format(-data.battery_v),
            "# voltage_max_v={}".format(data.battery_v),
            "# units=us,rad/s,V,ticks",
            "time_us,setpoint_rad_s,velocity_rad_s,limited_voltage_v,position_ticks"
        ]
        self.header_index = 0
        self.row_index = 0

    def taskuser_gen_fcn(self):
        self.menu()
        while True:
            if self.state == self.S_WAIT:
                if self.line_data.failed:
                    self.waiting_for_line_start = False
                    self.write_line("# LINE FOLLOWING STOPPED: " + self.line_data.error)
                    self.line_data.failed = False
                    self.menu()
                elif self.waiting_for_line_start and self.line_data.running:
                    self.waiting_for_line_start = False
                    self.write_line("Line following active.")
                elif self.vcp.any():
                    char = self.vcp.read(1)
                    if char in (b"\r", b"\n"):
                        yield self.state
                        continue
                    command = char.decode().lower()
                    self.write_line(">>> " + command)
                    if command == "h":
                        self.menu()
                    elif command == "v":
                        self.input.reset()
                        self.write_line("Enter a velocity (rad/s):")
                        self.state = self.S_VEL
                    elif command == "k":
                        self.write_line("Enter p/P for proportional gain:")
                        self.state = self.S_GAIN
                    elif command == "l":
                        self.start_test("LEFT")
                    elif command == "r":
                        self.start_test("RIGHT")
                    elif command == "b":
                        self.input.reset()
                        self.write_line("Enter base speed (rad/s):")
                        self.state = self.S_BASE
                    elif command == "g":
                        self.input.reset()
                        self.write_line("Enter line gain ((rad/s)/mm):")
                        self.state = self.S_STEER
                    elif command == "f":
                        self.start_line()
                    elif command == "c":
                        self.capture_line()
                    elif command == "s":
                        self.stop_line()
                    elif command == "e":
                        self.exit_program()
                    else:
                        self.write_line("Invalid command")
                        self.menu()

            elif self.state == self.S_VEL:
                if self.input.update():
                    if self.input.exit_requested:
                        self.exit_program()
                    elif self.input.stop_requested:
                        self.stop_line()
                    else:
                        value = self.input.get_value()
                        if self.input.was_changed() and abs(value) <= 50:
                            self.setpoint = value
                            self.write_line("Velocity set to {} rad/s".format(value))
                        elif self.input.was_changed():
                            self.write_line("Invalid velocity; use -50 to 50 rad/s")
                        self.menu()
                        self.state = self.S_WAIT

            elif self.state == self.S_GAIN:
                if self.vcp.any():
                    char = self.vcp.read(1)
                    if char in (b"p", b"P"):
                        self.input.reset()
                        self.write_line("Enter proportional gain:")
                        self.state = self.S_KP
                    elif char in (b"e", b"E"):
                        self.exit_program()
                    elif char in (b"s", b"S"):
                        self.stop_line()
                    elif char not in (b"\r", b"\n"):
                        self.write_line("Invalid gain selection; P only")
                        self.menu()
                        self.state = self.S_WAIT

            elif self.state == self.S_KP:
                if self.input.update():
                    if self.input.exit_requested:
                        self.exit_program()
                    elif self.input.stop_requested:
                        self.stop_line()
                    else:
                        value = self.input.get_value()
                        if self.input.was_changed() and 0 <= value <= 20:
                            self.kp = value
                            self.write_line("Kp set to {}".format(value))
                        elif self.input.was_changed():
                            self.write_line("Invalid Kp; use 0 to 20")
                        self.menu()
                        self.state = self.S_WAIT

            elif self.state == self.S_BASE:
                if self.input.update():
                    if self.input.exit_requested:
                        self.exit_program()
                    elif self.input.stop_requested:
                        self.stop_line()
                    else:
                        value = self.input.get_value()
                        if self.input.was_changed() and 0 < value <= MAX_WHEEL_RAD_S:
                            self.base_speed = value
                            self.write_line("Base speed set to {} rad/s".format(value))
                        elif self.input.was_changed():
                            self.write_line("Invalid base speed; use 0 to {}".format(MAX_WHEEL_RAD_S))
                        self.menu()
                        self.state = self.S_WAIT

            elif self.state == self.S_STEER:
                if self.input.update():
                    if self.input.exit_requested:
                        self.exit_program()
                    elif self.input.stop_requested:
                        self.stop_line()
                    else:
                        value = self.input.get_value()
                        if self.input.was_changed() and 0 <= value <= 2:
                            self.line_kp = value
                            self.write_line("Line gain set to {}".format(value))
                        elif self.input.was_changed():
                            self.write_line("Invalid line gain; use 0 to 2")
                        self.menu()
                        self.state = self.S_WAIT

            elif self.state == self.S_WAIT_RESULT:
                if not self.stop_during_test():
                    if self.active.failed:
                        self.write_line("# {} MOTOR TEST FAILED".format(self.name))
                        self.active = None
                        self.menu()
                        self.state = self.S_WAIT
                    elif self.active.ready:
                        self.make_header()
                        self.state = self.S_PRINT
                    elif not self.active.busy and not self.active.request:
                        self.write_line("# {} MOTOR TEST COMPLETE".format(self.name))
                        self.active = None
                        self.menu()
                        self.state = self.S_WAIT

            elif self.state == self.S_PRINT:
                if not self.stop_during_test():
                    if self.header_index < len(self.header):
                        self.write_line(self.header[self.header_index])
                        self.header_index += 1
                    elif self.row_index < self.active.count:
                        i = self.row_index
                        self.write_line("{},{},{},{},{}".format(
                            self.active.time_us[i], self.active.setpoint,
                            self.active.velocity[i], self.active.voltage[i],
                            self.active.position[i]))
                        self.row_index += 1
                    else:
                        self.active.ready = False
                        self.state = self.S_WAIT_RESULT

            elif self.state == self.S_LINE_WAIT:
                if self.vcp.any():
                    char = self.vcp.read(1)
                    if char in (b"s", b"S"):
                        self.stop_line()
                    elif char in (b"e", b"E"):
                        self.exit_program()
                elif self.line_data.failed:
                    self.write_line("# LINE DATA FAILED: " + self.line_data.error)
                    self.menu()
                    self.state = self.S_WAIT
                elif self.line_data.ready:
                    self.make_line_header()
                    self.state = self.S_LINE_PRINT
                elif not self.line_data.running:
                    self.write_line("# LINE DATA ABORTED")
                    self.menu()
                    self.state = self.S_WAIT

            elif self.state == self.S_LINE_PRINT:
                if self.vcp.any():
                    char = self.vcp.read(1)
                    if char in (b"s", b"S"):
                        self.stop_line()
                    elif char in (b"e", b"E"):
                        self.exit_program()
                elif self.header_index < len(self.header):
                    self.write_line(self.header[self.header_index])
                    self.header_index += 1
                elif self.row_index < self.line_data.count:
                    i = self.row_index
                    self.write_line("{},{},{},{},{}".format(
                        self.line_data.time_us[i], self.line_data.centroid_mm[i],
                        self.line_data.total_weight[i],
                        self.line_data.left_rad_s[i],
                        self.line_data.right_rad_s[i]))
                    self.row_index += 1
                else:
                    self.write_line("# LINE DATA COMPLETE")
                    self.line_data.ready = False
                    self.state = self.S_WAIT
                    self.menu()

            elif self.state == self.S_EXIT:
                pass

            yield self.state
