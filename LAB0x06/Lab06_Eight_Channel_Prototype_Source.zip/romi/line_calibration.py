"""Save/load measured black and white ADC values before the scheduler starts."""

import json
from pyb import delay


def load(sensor, filename):
    with open(filename, "r") as source:
        data = json.load(source)
    sensor.set_calibration(data["channels"], data["black"], data["white"])
    return data


def save(sensor, black, white, filename):
    sensor.set_calibration(sensor.channels, black, white)
    data = {"channels": list(sensor.channels),
            "black": list(black), "white": list(white)}
    with open(filename, "w") as target:
        json.dump(data, target)
    return data


def wait_for_enter(vcp):
    while True:
        if vcp.any():
            char = vcp.read(1)
            if char in (b"\r", b"\n"):
                return
        delay(50)  # Startup only: the cooperative scheduler is not running.


def capture_patch(sensor, vcp, name, frames=20):
    # Ignore a leftover LF if PuTTY sent CRLF for the previous Enter key.
    while vcp.any():
        vcp.read(1)
    vcp.write(("Place ALL connected sensors over {} and press Enter.\r\n"
               .format(name)).encode())
    wait_for_enter(vcp)
    totals = [0.0] * len(sensor.channels)
    for _ in range(frames):
        for i, reading in enumerate(sensor.read_raw()):
            totals[i] += reading
    return [total / frames for total in totals]


def calibrate(sensor, vcp, filename):
    black = capture_patch(sensor, vcp, "BLACK")
    white = capture_patch(sensor, vcp, "WHITE")
    data = save(sensor, black, white, filename)
    vcp.write(b"Calibration saved. Keep the same paper and emitter settings.\r\n")
    return data
