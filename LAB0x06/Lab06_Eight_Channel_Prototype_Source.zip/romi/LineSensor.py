"""Read, calibrate, and locate a black line using connected QTR analog pins."""

from pyb import ADC


class LineSensor:
    def __init__(self, sensor_pins, sensor_1_on_left, reads_per_channel=4,
                 min_span=30):
        if not sensor_pins or reads_per_channel < 1 or min_span <= 0:
            raise ValueError("Check sensor pins, ADC reads, and min_span")

        self.channels = tuple(number for number, pin in sensor_pins)
        if len(set(self.channels)) != len(self.channels) or any(
                number < 1 or number > 13 for number in self.channels):
            raise ValueError("Use distinct printed sensor numbers 1 through 13")

        self.adcs = tuple(ADC(pin) for number, pin in sensor_pins)
        self.reads_per_channel = reads_per_channel
        self.min_span = min_span
        self.raw = [0.0] * len(self.adcs)
        self.weights = [0.0] * len(self.adcs)
        self.black = None
        self.white = None
        self.total_weight = 0.0

        # Printed channel 7 is the center of the full 13-channel array.
        # Never renumber eight connected channels as though they were centered.
        self.positions_mm = None
        if sensor_1_on_left is not None:
            direction = 1 if sensor_1_on_left else -1
            self.positions_mm = tuple((7 - number) * 4 * direction
                                      for number in self.channels)

    def read_raw(self):
        """Return a reused list of raw ADC averages in sensor channel order."""
        for i, adc in enumerate(self.adcs):
            total = 0
            for _ in range(self.reads_per_channel):
                total += adc.read()
            self.raw[i] = total / self.reads_per_channel
        return self.raw

    def set_calibration(self, channels, black, white):
        if list(channels) != list(self.channels) or len(black) != len(self.adcs) or \
                len(white) != len(self.adcs):
            raise ValueError("Calibration channels do not match the pin map")
        for b, w in zip(black, white):
            if not (0 <= w < b <= 4095 and b - w >= self.min_span):
                raise ValueError("Invalid black/white span on a sensor")
        self.black = list(black)
        self.white = list(white)

    def centroid(self):
        """Return line position in mm (+left), or None on all-white/lost line."""
        if self.positions_mm is None:
            raise ValueError("Set SENSOR_1_ON_LEFT after checking physical order")
        if self.black is None:
            raise ValueError("Calibrate the line sensor before following")

        readings = self.read_raw()
        total = 0.0
        moment = 0.0
        for i, value in enumerate(readings):
            weight = (value - self.white[i]) / (self.black[i] - self.white[i])
            weight = max(0.0, min(1.0, weight))
            self.weights[i] = weight
            total += weight
            moment += weight * self.positions_mm[i]
        self.total_weight = total
        if total == 0:
            return None
        return moment / total
