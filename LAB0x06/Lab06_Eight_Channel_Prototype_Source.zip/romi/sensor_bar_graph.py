"""Standalone PuTTY wiring test; run with the motors off, outside scheduler."""

from pyb import USB_VCP, delay
from LineSensor import LineSensor
from line_config import (SENSOR_PINS, SENSOR_1_ON_LEFT,
                         ADC_READS_PER_CHANNEL, MIN_CALIBRATION_SPAN)


def make_frame(channels, readings, width=32):
    rows = ["Line sensor raw ADC values (q to quit)", "Sensor   ADC   Bar"]
    for channel, value in zip(channels, readings):
        length = int(width * min(4095, max(0, value)) / 4095)
        rows.append("{:>6}  {:>5.0f}  |{}{}|".format(
            channel, value, "#" * length, " " * (width - length)))
    return "\x1b[H" + "".join("\x1b[2K" + row + "\r\n" for row in rows)


def main():
    # Same ADC method, channel order, and averaging as runtime calibration.
    sensor = LineSensor(SENSOR_PINS, SENSOR_1_ON_LEFT,
                        ADC_READS_PER_CHANNEL, MIN_CALIBRATION_SPAN)
    vcp = USB_VCP()
    vcp.write(b"\x1b[2J\x1b[H")
    try:
        while True:
            if vcp.any():
                command = vcp.read()
                if command and (b"q" in command or b"Q" in command):
                    break
            vcp.write(make_frame(sensor.channels, sensor.read_raw()).encode())
            delay(100)  # Screen refresh only; not the scheduled line period.
    except KeyboardInterrupt:
        pass
    finally:
        vcp.write(b"\r\nSensor display stopped.\r\n")


if __name__ == "__main__":
    main()
