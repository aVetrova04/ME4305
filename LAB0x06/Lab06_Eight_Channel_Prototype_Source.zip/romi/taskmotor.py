from array import array
from math import pi
from time import ticks_us, ticks_diff, ticks_add


# change this if your measured encoder counts per wheel revolution differ.
COUNTS_PER_WHEEL_REV = 1440.0
SAMPLES = 100


class MotorData:
    """Commands and one fixed-size response shared with TaskUser."""

    def __init__(self):
        self.request = False
        self.busy = False
        self.ready = False
        self.failed = False
        self.setpoint = 0.0
        self.kp = 0.0
        self.battery_v = 0.0
        self.motor_period_ms = 10
        self.ui_period_ms = 20
        self.count = 0
        self.time_us = array('L', (0 for _ in range(SAMPLES)))
        self.velocity = array('f', (0 for _ in range(SAMPLES)))
        self.voltage = array('f', (0 for _ in range(SAMPLES)))
        self.position = array('l', (0 for _ in range(SAMPLES)))
        # Line mode: TaskLine writes targets; this task still owns the motor.
        self.follow_request = False
        self.follow_stop = False
        self.following = False
        self.follow_setpoint = 0.0
        self.follow_kp = 0.0
        self.stop_request = False

    def clear(self):
        self.count = 0


class TaskMotor:
    S_INIT = 0
    S_WAIT = 1
    S_SAMPLE = 2
    S_PRINT = 3
    S_PAUSE = 4
    S_FOLLOW = 5

    def __init__(self, motor, encoder, shared, controller, battery_v):
        self.motor = motor
        self.encoder = encoder
        self.data = shared
        self.controller = controller
        self.battery_v = battery_v
        self.data.battery_v = battery_v
        self.state = self.S_INIT
        self.start_us = 0
        self.next_us = 0
        self.pause_until_us = 0

    def taskmotor_gen_fcn(self):
        while True:
            if self.state == self.S_INIT:
                self.stop()
                self.state = self.S_WAIT

            elif self.state == self.S_WAIT:
                if self.data.follow_request and self.data.follow_stop:
                    self.data.follow_request = False
                    self.data.follow_stop = False
                elif self.data.follow_request:
                    self.data.follow_request = False
                    self.data.follow_stop = False
                    self.data.failed = False
                    self.controller.reset()
                    self.controller.set_kp(self.data.follow_kp)
                    self.controller.set_lim(-self.battery_v, self.battery_v)
                    self.controller.set_vel(self.data.follow_setpoint)
                    self.encoder.zero()
                    self.motor.set_effort(0)
                    self.motor.enable()
                    self.data.following = True
                    self.next_us = ticks_us()
                    self.state = self.S_FOLLOW
                elif self.data.request:
                    self.data.request = False
                    self.data.busy = True
                    self.data.ready = False
                    self.data.failed = False
                    self.data.clear()
                    self.encoder.zero()
                    self.controller.reset()
                    self.controller.set_vel(self.data.setpoint)
                    self.controller.set_kp(self.data.kp)
                    self.controller.set_lim(-self.battery_v, self.battery_v)
                    self.motor.set_effort(0)
                    self.motor.enable()
                    self.start_us = ticks_us()
                    self.next_us = self.start_us
                    self.state = self.S_SAMPLE

            elif self.state == self.S_SAMPLE:
                now = ticks_us()
                if self.data.stop_request:
                    self.stop()
                    self.state = self.S_WAIT
                elif ticks_diff(now, self.next_us) >= 0:
                    try:
                        self.encoder.update()
                        speed = self.encoder.get_velocity() * \
                                (2 * pi / COUNTS_PER_WHEEL_REV)
                        voltage = self.controller.update(speed)
                        self.motor.set_effort(100 * voltage / self.battery_v)
                        i = self.data.count
                        self.data.time_us[i] = ticks_diff(now, self.start_us)
                        self.data.velocity[i] = speed
                        self.data.voltage[i] = voltage
                        self.data.position[i] = self.encoder.get_position()
                        self.data.count += 1
                        self.next_us = ticks_add(self.next_us, 10_000)
                        if self.data.count >= SAMPLES:
                            self.motor.set_effort(0)
                            self.motor.disable()
                            self.data.ready = True
                            self.state = self.S_PRINT
                    except Exception:
                        self.motor.set_effort(0)
                        self.motor.disable()
                        self.data.failed = True
                        self.data.busy = False
                        self.state = self.S_WAIT

            elif self.state == self.S_PRINT:
                if not self.data.ready:
                    self.pause_until_us = ticks_add(ticks_us(), 1_000_000)
                    self.state = self.S_PAUSE

            elif self.state == self.S_PAUSE:
                if ticks_diff(ticks_us(), self.pause_until_us) >= 0:
                    self.data.busy = False
                    self.state = self.S_WAIT

            elif self.state == self.S_FOLLOW:
                if self.data.follow_stop:
                    self.stop()
                    self.state = self.S_WAIT
                else:
                    now = ticks_us()
                    if ticks_diff(now, self.next_us) >= 0:
                        try:
                            self.encoder.update()
                            speed = self.encoder.get_velocity() * \
                                    (2 * pi / COUNTS_PER_WHEEL_REV)
                            self.controller.set_vel(self.data.follow_setpoint)
                            voltage = self.controller.update(speed)
                            self.motor.set_effort(100 * voltage / self.battery_v)
                            self.next_us = ticks_add(now, 10_000)
                        except Exception:
                            self.stop()
                            self.data.failed = True
                            self.state = self.S_WAIT

            yield self.state

    def stop(self):
        self.motor.set_effort(0)
        self.motor.disable()
        self.data.request = False
        self.data.busy = False
        self.data.ready = False
        self.data.clear()
        self.data.follow_request = False
        self.data.follow_stop = False
        self.data.following = False
        self.data.follow_setpoint = 0.0
        self.data.stop_request = False
