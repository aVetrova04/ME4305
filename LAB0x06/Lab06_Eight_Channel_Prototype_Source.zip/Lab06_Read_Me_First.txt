LAB 0x06: FILES, SETUP, AND CODE WALKTHROUGH

For your partner's code handoff, read Lab06_Partner_Handoff.txt in this
bundle first. It lists the unverified wiring assumption and every file
to edit if the sensor connections or number of channels change.

Current status: eight wired sensor leads are a prototype. The code now
assumes a proposed sensor-side move from printed QTR outputs 1..8 to 3..10.
Do not use the new map until the physical leads match it. The assignment
specifies all 13 outputs and a separate ADC channel reserved for battery
sensing. Confirm a reduced-channel exception with the instructor or revise
the wiring before representing this as the final lab result.

Copy these files into Romi's root directory together:
  main.py, line_config.py, LineSensor.py, line_calibration.py, taskline.py,
  taskmotor.py, taskuser.py, MotorDriver.py, EncoderDriver.py, ClosedLoop.py,
  MultiChar.py. Keep the current boot.py if the board needs it. cotask is
  frozen in the firmware and is not a file you need to copy or submit.
  sensor_bar_graph.py is an optional standalone wiring test.
  For a quick test without changing existing Romi code, copy only
  quick_adc_check_center.py to Romi and run quick_adc_check_center.main()
  at the REPL. Its new module name avoids reusing the older, cached ADC
  test if that script was imported earlier in the same MicroPython session.
  This quick test does not import any other lab06 modules.

Copy romi_lab06_auto.py onto the MAC, not Romi. It needs pyserial and
matplotlib in the Python environment used to run it.

Before moving Romi:
  1. Turn power OFF before moving a lead. Reconnect the eight existing
     MCU leads to printed QTR output numbers 3 through 10 as follows:
       old lead W1 -> QTR 3 -> PC0; Y2 -> QTR 4 -> PC1;
       W3 -> QTR 5 -> PC2; Y4 -> QTR 6 -> PC3;
       W5 -> QTR 7 -> PA4; Y6 -> QTR 8 -> PC4;
       W7 -> QTR 9 -> PB0; Y8 -> QTR 10 -> PB1.
     Keep sensor VCC -> AVDD (CN5 pin 8) and ground -> CN10 pin 20.
     Never connect an analog output at 5 V.
  2. With wheels raised and main.py stopped using Ctrl-C, run
        import quick_adc_check_center
        quick_adc_check_center.main()
     Move the supplied white/black patches under EACH connected sensor.
     Black should read higher. Pass a thin line under each channel in
     numbered order, including centered output 7. Press q to stop.
     In SENSOR_MAP, (3, "C0") means QTR output number 3 is connected to
     MCU PC0. Change 3 if that output is a different printed QTR channel;
     change C0 only if its MCU wire has moved. Keep all connected output
     numbers distinct, 1 through 13. Merely renumbering cannot add the
     five unconnected QTR outputs.
  3. In line_config.py set SENSOR_1_ON_LEFT to True if the lower printed
     numbers (for example output 3) are to Romi's left, False if to its
     right. Check on the mounted Romi, facing forward. Output 7 is the
     true center of the full bar; eight consecutive outputs cannot be
     perfectly symmetric around a single central output. Do not reuse a
     calibration JSON from the old 1..8 wiring.
  4. Edit CALIBRATE_ON_BOOT = True and restart with PuTTY available.
     Follow BLACK then WHITE placement prompts on the provided paper.
     This writes REAL ADC readings to line_calibration.json. Confirm
     every channel has positive black-white contrast. Change the flag
     back to False and restart to load the recorded calibration.
  5. With fences and an immediate stop ready, use the existing v/k/l/r
     commands to retune BOTH motor velocity loops under surface load.
     Set a measured battery value in main.py and test modest speeds.
  6. With wheels raised, use k then p (loaded inner Kp), b (base rad/s),
     and g (outer gain in rad/s/mm), then f to follow. A line to Romi's
     LEFT must request a faster RIGHT wheel; a line to the RIGHT must
     request a faster LEFT wheel. Press s to stop or e to exit.
  7. Use c while following to capture 400 samples at 20 ms spacing.
     The capture lasts about 8 seconds; Romi continues following until
     you press s. The PC script sets gains, starts following, collects,
     saves CSV+PNG, and then stops. Update PORT and gains in the Mac
     script first. The saved CSV includes configuration comments.

Python ideas used here:
  - import: load a class or function from another file in the same folder.
    Example: 'from LineSensor import LineSensor' loads one class.
  - object: 'sensor = LineSensor(...)' calls __init__ once and stores
    sensor-specific data in attributes like sensor.black and sensor.raw.
  - method: 'sensor.read_raw()' is a function on that object. The first
    parameter 'self' means the particular object being used.
  - list vs tuple: SENSOR_PINS is a fixed tuple of channel/pin pairs;
    sensor.raw is a list because readings are overwritten every update.
  - shared data: TaskLine sets left_data.follow_setpoint and
    right_data.follow_setpoint. Each TaskMotor reads its own setpoint
    and alone touches its motor pins. TaskUser alone reads/writes VCP.
  - generator: a function with 'yield' pauses after one short step.
    cotask calls it again when the task's period elapses. The 'state'
    number selects the step to run next time.
  - calibration: for each channel, weight is
       clip((reading - white) / (black - white), 0, 1).
    The centroid is sum(weight * physical_mm) / sum(weight). A sum of
    zero causes safe stop instead of division by zero.
  - outer P control: correction = line_kp * centroid_mm. Requested
    left speed = base - correction; requested right speed = base +
    correction. Each inner P controller turns its speed error into
    motor voltage, then MotorDriver turns voltage into PWM duty cycle.

No line_calibration.json, CSV, PNG, or video are included in this folder.
They must come from a real calibration, test run, and demonstration.
