#!/usr/bin/env python3
"""Run one line-following capture from a Mac; save CSV, plot, and serial log."""

import csv
from datetime import datetime
from math import isclose, isfinite
from pathlib import Path
from time import monotonic

from matplotlib import pyplot as plt
from serial import Serial, SerialException


# Change these after loaded-wheel tests. Close PuTTY before running this script.
PORT = "/dev/cu.usbmodem205D32904E332"
BAUD = 115200
BASE_RAD_S = 2.0
INNER_KP = 0.5
LINE_KP = 0.05

CSV_HEADER = ["time_us", "centroid_mm", "total_weight",
              "left_setpoint_rad_s", "right_setpoint_rad_s"]


def read_line(ser, seconds, log):
    end = monotonic() + seconds
    while monotonic() < end:
        raw = ser.readline()
        if raw:
            line = raw.decode("utf-8", errors="replace").strip()
            if line:
                log.write(line + "\n")
                return line
    raise TimeoutError("Romi did not send the expected line")


def check_error(line):
    if line.startswith(("Invalid", "Traceback", "Capture unavailable",
                        "Wait for", "Set a positive", "Line following is already")) or \
            "FAILED" in line or "ABORTED" in line or \
            "LINE FOLLOWING STOPPED" in line or line == ">>>":
        raise RuntimeError("Romi: " + line)


def wait_for(ser, expected, log, seconds=20):
    end = monotonic() + seconds
    while monotonic() < end:
        line = read_line(ser, max(0.01, end - monotonic()), log)
        if line == expected:
            return
        check_error(line)
        print("Romi:", line)
    raise TimeoutError("Waiting for " + expected)


def wait_for_value(ser, prefix, requested, log):
    end = monotonic() + 20
    while monotonic() < end:
        line = read_line(ser, max(0.01, end - monotonic()), log)
        if line.startswith(prefix):
            try:
                actual = float(line[len(prefix):].split()[0])
            except (ValueError, IndexError) as error:
                raise ValueError("Bad number confirmation: " + line) from error
            if not isclose(actual, requested, rel_tol=1e-6, abs_tol=1e-7):
                raise ValueError("Romi accepted a different number: " + line)
            return
        check_error(line)
        print("Romi:", line)
    raise TimeoutError("Waiting for " + prefix)


def set_number(ser, command, prompt, answer, prefix, log):
    ser.write(command.encode("ascii"))  # One command character, no line ending.
    wait_for(ser, prompt, log)
    ser.write(("{:g}\r".format(answer)).encode("ascii"))
    wait_for_value(ser, prefix, answer, log)


def set_settings(ser, log):
    ser.write(b"k")
    wait_for(ser, "Enter p/P for proportional gain:", log)
    ser.write(b"p")
    wait_for(ser, "Enter proportional gain:", log)
    ser.write(("{:g}\r".format(INNER_KP)).encode("ascii"))
    wait_for_value(ser, "Kp set to ", INNER_KP, log)
    set_number(ser, "b", "Enter base speed (rad/s):", BASE_RAD_S,
               "Base speed set to ", log)
    set_number(ser, "g", "Enter line gain ((rad/s)/mm):", LINE_KP,
               "Line gain set to ", log)


def collect(ser, log):
    wait_for(ser, "# LINE FOLLOWING DATA", log, seconds=90)
    notes = ["# LINE FOLLOWING DATA"]
    settings = {}
    rows = []
    header_found = False
    while True:
        line = read_line(ser, 15, log)
        check_error(line)
        if line == "# LINE DATA COMPLETE":
            break
        if not header_found and line.startswith("# "):
            notes.append(line)
            if "=" in line:
                key, value = line[2:].split("=", 1)
                settings[key.strip()] = value.strip()
            continue
        if not header_found:
            if line.split(",") != CSV_HEADER:
                raise ValueError("Unexpected CSV columns: " + line)
            header_found = True
            continue
        fields = [field.strip() for field in line.split(",")]
        if len(fields) != len(CSV_HEADER):
            raise ValueError("Bad data row: " + line)
        try:
            values = [float(field) for field in fields]
        except ValueError as error:
            raise ValueError("Nonnumeric data row: " + line) from error
        if not all(isfinite(value) for value in values):
            raise ValueError("Nonfinite data row: " + line)
        rows.append(fields)
        if len(rows) > 10000:
            raise ValueError("Too many rows from Romi")

    required = ("sensor_channels", "sensor_count", "channel_1_side",
                "adc_method", "adc_reads_per_channel", "base_rad_s",
                "outer_kp_rad_s_per_mm", "inner_kp_v_per_rad_s",
                "motor_period_ms", "line_period_ms", "ui_period_ms",
                "max_wheel_rad_s", "battery_voltage_v", "samples", "units")
    if not header_found or any(key not in settings for key in required):
        raise ValueError("Dataset header or test settings are missing")
    if len(rows) != int(settings["samples"]):
        raise ValueError("Only {} of {} data rows arrived".format(
            len(rows), settings["samples"]))
    for key, requested in (("base_rad_s", BASE_RAD_S),
                           ("outer_kp_rad_s_per_mm", LINE_KP),
                           ("inner_kp_v_per_rad_s", INNER_KP)):
        if not isclose(float(settings[key]), requested, abs_tol=1e-6):
            raise ValueError("Romi returned the wrong setting for " + key)
    return notes, settings, rows


def save_run(folder, notes, settings, rows):
    base = folder / "line_following"
    # Comments are inside the CSV so the run settings stay with its data.
    with base.with_suffix(".csv").open("x", newline="", encoding="utf-8") as out:
        for note in notes:
            out.write(note + "\n")
        writer = csv.writer(out)
        writer.writerow(CSV_HEADER)
        writer.writerows(rows)

    times = [float(row[0]) / 1_000_000 for row in rows]
    centroid = [float(row[1]) for row in rows]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(times, centroid, color="0.25", label="Measured centroid")
    ax.axhline(0, color="k", linestyle="--", label="Sensor center")
    ax.set(xlabel="Time from capture start (s)", ylabel="Centroid (mm)",
           title="Line follow | base {:g} rad/s | outer Kp {:g} (rad/s)/mm\n"
                 "wheel Kp {:g} V/(rad/s) | {} sensors".format(
                     BASE_RAD_S, LINE_KP, INNER_KP, settings["sensor_count"]))
    ax.legend()
    ax.grid(True)
    fig.tight_layout()
    try:
        fig.savefig(base.with_suffix(".png"), dpi=200)
    finally:
        plt.close(fig)
    print("Saved {} rows and plot in {}".format(len(rows), folder))


def main():
    if not (0 < BASE_RAD_S <= 10 and 0 < INNER_KP <= 20 and
            0 <= LINE_KP <= 2 and all(isfinite(x) for x in
                                      (BASE_RAD_S, INNER_KP, LINE_KP))):
        raise ValueError("Check configured speeds and gains")

    folder = Path("romi_lab06_runs") / datetime.now().strftime(
        "%Y-%m-%d_%H-%M-%S_%f")
    folder.mkdir(parents=True, exist_ok=False)
    print("Opening", PORT, "at", BAUD, "baud")
    try:
        with (folder / "serial.log").open("x", encoding="utf-8", buffering=1) as log:
            with Serial(PORT, baudrate=BAUD, timeout=0.25) as ser:
                try:
                    ser.reset_input_buffer()
                    set_settings(ser, log)
                    ser.write(b"f")
                    wait_for(ser, "Starting line following.", log)
                    wait_for(ser, "Line following active.", log)
                    ser.write(b"c")
                    wait_for(ser, "Line data capture started.", log)
                    notes, settings, rows = collect(ser, log)
                    save_run(folder, notes, settings, rows)
                    ser.write(b"s")
                    wait_for(ser, "Line following stop requested.", log)
                    ser.write(b"e")
                    wait_for(ser, "Exit requested.", log)
                    print("Done. Results:", folder)
                except BaseException:
                    # A single s is handled by the UI even during dataset output.
                    try:
                        ser.write(b"s")
                    except (SerialException, OSError):
                        pass
                    print("Stopped. Check", folder / "serial.log")
                    raise
    except SerialException as error:
        raise SystemExit("Serial error: " + str(error)) from error


if __name__ == "__main__":
    main()
